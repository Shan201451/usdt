//
//  unsbx.swift
//  mond
//
//  Created by ruter on 11.08.26.
//

import Foundation

private var list_cache: [String: [String]] = [:]
private let list_cache_lock = NSLock()

func grant_access(_ path: String, probe_leaf: String?, msg: String) -> Int64 {
    var path_c = path.utf8CString.map { Int8($0) }
    let handle: Int64

    if let probe_leaf {
        var probe_c = probe_leaf.utf8CString.map { Int8($0) }
        handle = bad_query(&path_c, false, nil, false, &probe_c)
    } else {
        handle = bad_query(&path_c, false, nil, false, nil)
    }

    switch handle {
    case -1:
        print("(bq) failed to resolve one or more functions")
    case -2:
        print("(bq) failed to create sandbox query")
    case -3:
        print("(bq) outside of containermanager's sandbox")
    case -4:
        print("(bq) kernel rejected sandbox query")
    default:
        print("(bq) \(msg) handle: \(handle)")
    }

    return handle
}

func grant_mg() -> Int64 {
    return grant_access(TweakPaths.gestalt_dir, probe_leaf: "com.apple.MobileGestalt.plist", msg: "granted mg access!")
}

func list_containers(_ root: String) -> [String] {
    var norm = root
    if norm.hasPrefix("/private/") { norm.removeFirst("/private/".count - 1) }
    if norm.hasSuffix("/") { norm.removeLast() }

    list_cache_lock.lock()
    defer { list_cache_lock.unlock() }

    if let cached = list_cache[norm] {
        return cached
    }

    var path_c = norm.utf8CString.map { Int8($0) }
    guard let raw = bad_query_list(&path_c, 2_000_000) else { return [] }
    defer { free(raw) }

    let list = String(cString: raw)
        .split(whereSeparator: \.isNewline)
        .map(String.init)
        .filter { !$0.isEmpty }

    list_cache[norm] = list
    return list
}

func grant_pb() -> Int64 {
    do {
        let container = try pb.find_pb_container()
        let probe_dir = pb.descriptors_url(container: container, ext: pb.collections_ext)
        _ = try? pb.ensure_directory(at: probe_dir.path)

        var path_c = probe_dir.path.utf8CString.map { Int8($0) }
        let handle = bad_query(&path_c, true, nil, false, nil)

        if handle >= 0 {
            print("(bq) granted pb access! handle: \(handle)")
            return handle
        }

        print("(bq) kernel rejected sandbox query for \(probe_dir.path)")
        return handle
    } catch {
        print("(pb) failed to find pb container: \(error.localizedDescription)")
        return -1
    }
}

func grant_apps() -> Int64 {
    for root in pb.container_roots {
        let children = list_containers(root)
        guard let target = children.first else { continue }

        var path_c = target.utf8CString.map { Int8($0) }
        let handle = bad_query(&path_c, true, nil, false, nil)

        if handle >= 0 {
            print("(bq) granted apps container access to \(target) handle: \(handle)")
        } else {
            print("(bq) kernel rejected sandbox query for \(target)")
        }

        return handle
    }

    print("(bq) no app containers found")
    return -1
}

func grant_all(state: AppState) {
    if UserDefaults.standard.string(forKey: "method") == "cmg" {
        let result = cmg()
        state.mg_granted = result >= 0
        state.pb_granted = false
        state.apps_granted = false
        state.exploit_succeeded = result >= 0
        return
    }

    state.pb_granted = nil
    state.granting_pb = true
    state.apps_granted = nil
    state.granting_apps = true
    state.mg_granted = nil
    state.granting_mg = true

    DispatchQueue.global(qos: .userInitiated).async {
        _ = list_containers(TweakPaths.apps)

        let mg = grant_mg()
        let pb = grant_pb()
        let apps = grant_apps()

        DispatchQueue.main.async {
            state.granting_pb = false
            state.pb_granted = pb >= 0
            state.granting_apps = false
            state.apps_granted = apps >= 0
            state.granting_mg = false
            state.mg_granted = mg >= 0
            state.exploit_succeeded = mg >= 0 && apps >= 0 && pb >= 0
        }
    }
}
